<template>
  <div class="todo-list">
    <div class="todo-list-header">
      <div class="header-left">
        <h4>Todos</h4>
        <span class="todo-progress" v-if="todos.length > 0">
          {{ todosConcluidos }}/{{ todos.length }} concluídos
        </span>
      </div>
      <div class="header-actions">
        <Button
          v-if="todos.length > 0 && todosConcluidos < todos.length"
          @click="marcarTodosConcluidos"
          class="btn-small"
        >
          Marcar todos
        </Button>
        <Button @click="openModal">+ Adicionar</Button>
      </div>
    </div>
    <div v-if="todos.length === 0" class="empty-state">
      <p>Nenhum todo ainda. Adicione o primeiro!</p>
    </div>
    <div v-else class="todo-items">
      <TransitionGroup name="todo-list" tag="div">
        <TodoItem
          v-for="todo in todosOrdenados"
          :key="todo.id"
          :todo="todo"
          @edit="editTodo"
          @delete="deleteTodo"
          @update="updateTodo"
        />
      </TransitionGroup>
    </div>

    <Modal
      v-model:show="showModal"
      :title="editingTodo && editingTodo.id ? 'Editar Todo' : 'Novo Todo'"
      @confirm="saveTodo"
      @close="closeModal"
    >
      <Input
        id="descricao"
        v-model="form.descricao"
        label="Descrição"
        placeholder="Ex: Verificar conexões"
        :error="errors.descricao"
        required
      />
    </Modal>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue';
import { useToast } from 'vue-toastification';
import { todoService } from '../../services/todoService.js';
import TodoItem from './TodoItem.vue';
import Modal from '../common/Modal.vue';
import Button from '../common/Button.vue';
import Input from '../common/Input.vue';

const props = defineProps({
  tarefaId: {
    type: Number,
    required: true
  }
});

const emit = defineEmits(['todos-updated']);

const toast = useToast();

const todos = ref([]);
const showModal = ref(false);
const editingTodo = ref(null);
const form = ref({ descricao: '' });
const errors = ref({});

const todosConcluidos = computed(() => {
  return todos.value.filter(t => t.concluido).length;
});

// Ordenar todos: pendentes primeiro, depois concluídos
const todosOrdenados = computed(() => {
  return [...todos.value].sort((a, b) => {
    if (a.concluido === b.concluido) {
      return new Date(a.created_at) - new Date(b.created_at);
    }
    return a.concluido ? 1 : -1;
  });
});

const loadTodos = async () => {
  try {
    todos.value = await todoService.getByTarefa(props.tarefaId);
  } catch (error) {
    toast.error('Erro ao carregar todos');
  }
};

watch(() => props.tarefaId, () => {
  if (props.tarefaId) {
    loadTodos();
  }
}, { immediate: true });

const openModal = (todo = null) => {
  // Limpar estado anterior
  editingTodo.value = null;
  form.value = { descricao: '' };
  errors.value = {};
  
  // Se for edição, preencher os dados
  if (todo && todo.id) {
    editingTodo.value = todo;
    form.value = { descricao: todo.descricao };
  }
  
  showModal.value = true;
};

const closeModal = () => {
  showModal.value = false;
  editingTodo.value = null;
  form.value = { descricao: '' };
  errors.value = {};
};

const saveTodo = async () => {
  if (!form.value.descricao.trim()) {
    errors.value.descricao = 'Descrição é obrigatória';
    return;
  }

  try {
    // Verificar se é edição (deve ter id válido)
    if (editingTodo.value && editingTodo.value.id) {
      await todoService.update(editingTodo.value.id, form.value);
      toast.success('Todo atualizado com sucesso!');
    } else {
      await todoService.create(props.tarefaId, form.value);
      toast.success('Todo criado com sucesso!');
    }
    closeModal();
    await loadTodos();
    emit('todos-updated');
  } catch (error) {
    toast.error(error.response?.data?.error || 'Erro ao salvar todo');
    console.error('Erro ao salvar todo:', error);
  }
};

const editTodo = (todo) => {
  openModal(todo);
};

const deleteTodo = async (id) => {
  if (!confirm('Tem certeza que deseja excluir este todo?')) {
    return;
  }

  try {
    await todoService.delete(id);
    toast.success('Todo excluído com sucesso!');
    await loadTodos();
    emit('todos-updated');
  } catch (error) {
    toast.error('Erro ao excluir todo');
  }
};

const updateTodo = (updatedTodo) => {
  const index = todos.value.findIndex(t => t.id === updatedTodo.id);
  if (index !== -1) {
    // Atualizar o item na lista de forma reativa
    todos.value[index] = { ...updatedTodo };
    // Emitir evento para atualizar contadores externos
    emit('todos-updated');
  } else {
    // Se não encontrou, recarregar a lista
    loadTodos();
  }
};

const marcarTodosConcluidos = async () => {
  const pendentes = todos.value.filter(t => !t.concluido);
  
  if (pendentes.length === 0) return;
  
  // Atualização otimista - atualizar UI imediatamente
  pendentes.forEach(todo => {
    const index = todos.value.findIndex(t => t.id === todo.id);
    if (index !== -1) {
      todos.value[index] = { ...todo, concluido: true };
    }
  });
  
  try {
    const promises = pendentes.map(todo =>
      todoService.update(todo.id, { concluido: true })
    );
    await Promise.all(promises);
    toast.success('Todos marcados como concluídos!');
    // Recarregar para garantir sincronização
    loadTodos();
  } catch (error) {
    // Reverter em caso de erro
    loadTodos();
    toast.error('Erro ao marcar todos como concluídos');
  }
};
</script>

<style scoped>
.todo-list {
  margin-top: 1.5rem;
}

.todo-list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  gap: 1rem;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.todo-list-header h4 {
  font-size: 1.125rem;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.todo-progress {
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--primary-color);
  padding: 0.25rem 0.75rem;
  background-color: rgba(79, 70, 229, 0.1);
  border-radius: 9999px;
}

.header-actions {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.btn-small {
  padding: 0.375rem 0.75rem;
  font-size: 0.8125rem;
}

.todo-items {
  max-height: 400px;
  overflow-y: auto;
}

.empty-state {
  text-align: center;
  padding: 2rem;
  color: var(--text-light);
  font-size: 0.875rem;
}

/* Animações para transições */
.todo-list-enter-active,
.todo-list-leave-active {
  transition: all 0.3s ease;
}

.todo-list-enter-from {
  opacity: 0;
  transform: translateY(-10px);
}

.todo-list-leave-to {
  opacity: 0;
  transform: translateX(20px);
}

.todo-list-move {
  transition: transform 0.3s ease;
}
</style>
