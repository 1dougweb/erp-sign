import pool from '../config/database.js';

export const getTodos = async (req, res) => {
  try {
    const { tarefaId } = req.params;

    const [todos] = await pool.execute(
      'SELECT * FROM todos WHERE tarefa_id = ? ORDER BY created_at ASC',
      [tarefaId]
    );
    res.json(todos);
  } catch (error) {
    console.error('Erro ao buscar todos:', error);
    res.status(500).json({ error: 'Erro ao buscar todos' });
  }
};

export const createTodo = async (req, res) => {
  try {
    const { tarefaId } = req.params;
    const { descricao } = req.body;

    if (!descricao) {
      return res.status(400).json({ error: 'Descrição do todo é obrigatória' });
    }

    // Verificar se a tarefa pertence a um projeto do usuário
    const [tarefas] = await pool.execute(
      `SELECT t.* FROM tarefas t 
       INNER JOIN projetos p ON t.projeto_id = p.id 
       WHERE t.id = ? AND p.user_id = ?`,
      [tarefaId, req.user.id]
    );

    if (tarefas.length === 0) {
      return res.status(404).json({ error: 'Tarefa não encontrada' });
    }

    const [result] = await pool.execute(
      'INSERT INTO todos (tarefa_id, descricao) VALUES (?, ?)',
      [tarefaId, descricao]
    );

    const [todo] = await pool.execute(
      'SELECT * FROM todos WHERE id = ?',
      [result.insertId]
    );

    res.status(201).json(todo[0]);
  } catch (error) {
    console.error('Erro ao criar todo:', error);
    res.status(500).json({ error: 'Erro ao criar todo' });
  }
};

export const updateTodo = async (req, res) => {
  try {
    const { id } = req.params;
    const { descricao, concluido } = req.body;

    // Verificar se o todo pertence a uma tarefa de um projeto do usuário
    const [todos] = await pool.execute(
      `SELECT td.* FROM todos td 
       INNER JOIN tarefas t ON td.tarefa_id = t.id 
       INNER JOIN projetos p ON t.projeto_id = p.id 
       WHERE td.id = ? AND p.user_id = ?`,
      [id, req.user.id]
    );

    if (todos.length === 0) {
      return res.status(404).json({ error: 'Todo não encontrado' });
    }

    const updateFields = [];
    const updateValues = [];

    if (descricao !== undefined) {
      updateFields.push('descricao = ?');
      updateValues.push(descricao);
    }

    if (concluido !== undefined) {
      updateFields.push('concluido = ?');
      updateValues.push(concluido);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({ error: 'Nenhum campo para atualizar' });
    }

    updateValues.push(id);

    await pool.execute(
      `UPDATE todos SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    const [updated] = await pool.execute(
      'SELECT * FROM todos WHERE id = ?',
      [id]
    );

    res.json(updated[0]);
  } catch (error) {
    console.error('Erro ao atualizar todo:', error);
    res.status(500).json({ error: 'Erro ao atualizar todo' });
  }
};

export const deleteTodo = async (req, res) => {
  try {
    const { id } = req.params;

    // Verificar se o todo pertence a uma tarefa de um projeto do usuário
    const [todos] = await pool.execute(
      `SELECT td.* FROM todos td 
       INNER JOIN tarefas t ON td.tarefa_id = t.id 
       INNER JOIN projetos p ON t.projeto_id = p.id 
       WHERE td.id = ? AND p.user_id = ?`,
      [id, req.user.id]
    );

    if (todos.length === 0) {
      return res.status(404).json({ error: 'Todo não encontrado' });
    }

    await pool.execute('DELETE FROM todos WHERE id = ?', [id]);

    res.json({ message: 'Todo excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir todo:', error);
    res.status(500).json({ error: 'Erro ao excluir todo' });
  }
};
