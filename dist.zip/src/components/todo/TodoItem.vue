<template>
  <div class="todo-item" :class="{ 'todo-concluido': todo.concluido }">
    <label class="todo-checkbox">
      <input
        type="checkbox"
        :checked="todo.concluido"
        @change="toggleConcluido"
      />
      <span class="todo-descricao">{{ todo.descricao }}</span>
    </label>
    <div class="todo-actions">
      <button class="btn-icon" @click="$emit('edit', todo)" title="Editar">
        <PencilIcon class="icon" />
      </button>
      <button class="btn-icon btn-danger" @click="$emit('delete', todo.id)" title="Excluir">
        <TrashIcon class="icon" />
      </button>
    </div>
  </div>
</template>

<script setup>
import { PencilIcon, TrashIcon } from '@heroicons/vue/24/outline';
import { todoService } from '../../services/todoService.js';
import { useToast } from 'vue-toastification';

const props = defineProps({
  todo: {
    type: Object,
    required: true
  }
});

const emit = defineEmits(['edit', 'delete', 'update']);

const toast = useToast();

const toggleConcluido = async () => {
  const novoEstado = !props.todo.concluido;
  
  // Atualização otimista - atualizar UI imediatamente
  const todoOtimista = { ...props.todo, concluido: novoEstado };
  emit('update', todoOtimista);
  
  try {
    const updated = await todoService.update(props.todo.id, {
      concluido: novoEstado
    });
    // Atualizar com dados do servidor
    emit('update', updated);
  } catch (error) {
    // Reverter em caso de erro
    emit('update', props.todo);
    toast.error('Erro ao atualizar todo');
  }
};
</script>

<style scoped>
.todo-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  background-color: var(--bg-color);
  border-radius: 0.375rem;
  margin-bottom: 0.5rem;
  transition: background-color 0.2s;
}

.todo-item:hover {
  background-color: #f3f4f6;
}

.todo-concluido {
  opacity: 0.7;
  background-color: #f0fdf4;
  border-left: 3px solid var(--secondary-color);
}

.todo-checkbox {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex: 1;
  cursor: pointer;
}

.todo-checkbox input[type="checkbox"] {
  width: 1.25rem;
  height: 1.25rem;
  cursor: pointer;
}

.todo-descricao {
  font-size: 0.875rem;
  color: var(--text-color);
}

.todo-concluido .todo-descricao {
  text-decoration: line-through;
  color: var(--text-light);
}

.todo-actions {
  display: flex;
  gap: 0.5rem;
}

.btn-icon {
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.25rem;
  opacity: 0.7;
  transition: opacity 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-icon:hover {
  opacity: 1;
}

.btn-icon .icon {
  width: 1rem;
  height: 1rem;
}

.btn-icon.btn-danger .icon {
  color: var(--danger-color);
}
</style>
