<template>
  <div class="cronograma-page">
    <div class="page-header">
      <h1 class="page-title">Cronograma de Instalação</h1>
      <Button @click="openModal">+ Novo Cronograma</Button>
    </div>

    <Loading v-if="loading" />
    <div v-else-if="cronogramas.length === 0" class="empty-state">
      <p>Nenhum cronograma cadastrado. Crie o primeiro!</p>
    </div>
    <div v-else class="cronogramas-list">
      <div v-for="cronograma in cronogramas" :key="cronograma.id" class="cronograma-card">
        <div class="cronograma-header">
          <div>
            <h3>{{ cronograma.orcamento_numero ? `Orçamento ${cronograma.orcamento_numero}` : 'Cronograma #' + cronograma.id }}</h3>
            <p v-if="cronograma.cliente_nome" class="cronograma-cliente">{{ cronograma.cliente_nome }}</p>
            <p class="cronograma-data">
              📅 {{ formatDate(cronograma.data_instalacao) }}
              <span v-if="cronograma.hora_inicio">
                às {{ cronograma.hora_inicio }}
              </span>
            </p>
          </div>
          <div class="cronograma-actions">
            <span :class="['status-badge', getStatusClass(cronograma.status)]">
              {{ getStatusLabel(cronograma.status) }}
            </span>
            <button class="btn btn-outline" @click="editCronograma(cronograma)">Editar</button>
            <button class="btn btn-danger" @click="deleteCronograma(cronograma.id)">Excluir</button>
          </div>
        </div>
        <div class="cronograma-info">
          <p><strong>Endereço:</strong> {{ cronograma.endereco }}</p>
          <div v-if="cronograma.equipes && cronograma.equipes.length > 0" class="cronograma-section">
            <strong>Equipes:</strong>
            <div class="tags-list">
              <span v-for="equipe in cronograma.equipes" :key="equipe.id" class="tag">
                {{ equipe.nome }}
              </span>
            </div>
          </div>
          <div v-if="cronograma.materiais && cronograma.materiais.length > 0" class="cronograma-section">
            <ChecklistMaterial
              :cronograma-id="cronograma.id"
              :materiais="cronograma.materiais"
              @update="loadData"
            />
          </div>
          <div v-if="cronograma.carros && cronograma.carros.length > 0" class="cronograma-section">
            <strong>Carros:</strong>
            <div class="tags-list">
              <span v-for="carro in cronograma.carros" :key="carro.id" class="tag">
                {{ carro.placa }} - {{ carro.modelo }}
              </span>
            </div>
          </div>
          <p v-if="cronograma.observacoes" class="cronograma-observacoes">
            <strong>Observações:</strong> {{ cronograma.observacoes }}
          </p>
        </div>
      </div>
    </div>

    <Offcanvas
      v-model:show="showModal"
      :title="editingCronograma && editingCronograma.id ? 'Editar Cronograma' : 'Novo Cronograma'"
      position="right"
      @confirm="saveCronograma"
      @close="closeModal"
    >
      <form @submit.prevent="saveCronograma" class="form">
        <div class="input-group">
          <label for="orcamento_id" class="input-label">Orçamento (Opcional)</label>
          <select id="orcamento_id" v-model="form.orcamento_id" class="input">
            <option :value="null">Selecione um orçamento...</option>
            <option
              v-for="orcamento in orcamentos"
              :key="orcamento.id"
              :value="orcamento.id"
            >
              {{ orcamento.numero }} - {{ orcamento.cliente_nome }}
            </option>
          </select>
        </div>
        <div class="form-row">
          <Input
            id="data_instalacao"
            v-model="form.data_instalacao"
            label="Data de Instalação"
            type="date"
            :error="errors.data_instalacao"
            required
          />
          <div class="form-row-small">
            <Input
              id="hora_inicio"
              v-model="form.hora_inicio"
              label="Hora Início"
              type="time"
            />
            <Input
              id="hora_fim"
              v-model="form.hora_fim"
              label="Hora Fim"
              type="time"
            />
          </div>
        </div>
        <div class="input-group">
          <label for="endereco" class="input-label">Endereço</label>
          <textarea
            id="endereco"
            v-model="form.endereco"
            class="textarea"
            rows="2"
            :error="errors.endereco"
            required
          ></textarea>
        </div>
        <div class="input-group">
          <label for="equipes" class="input-label">Equipes</label>
          <select id="equipes" v-model="form.equipes" multiple class="input" style="min-height: 100px;">
            <option
              v-for="equipe in equipes"
              :key="equipe.id"
              :value="equipe.id"
            >
              {{ equipe.nome }}
            </option>
          </select>
        </div>
        <div class="input-group">
          <label for="materiais" class="input-label">Materiais</label>
          <div class="materiais-select">
            <div
              v-for="material in materiais"
              :key="material.id"
              class="material-select-item"
            >
              <label>
                <input
                  type="checkbox"
                  :value="material.id"
                  v-model="selectedMateriais"
                />
                {{ material.nome }}
              </label>
              <Input
                v-if="selectedMateriais.includes(material.id)"
                v-model.number="materialQuantidades[material.id]"
                type="number"
                min="1"
                placeholder="Qtd"
                style="width: 80px; margin-left: 0.5rem;"
              />
            </div>
          </div>
        </div>
        <div class="input-group">
          <label for="carros" class="input-label">Carros</label>
          <select id="carros" v-model="form.carros" multiple class="input" style="min-height: 80px;">
            <option
              v-for="carro in carros"
              :key="carro.id"
              :value="carro.id"
            >
              {{ carro.placa }} - {{ carro.modelo }}
            </option>
          </select>
        </div>
        <div class="input-group">
          <label for="status" class="input-label">Status</label>
          <select id="status" v-model="form.status" class="input">
            <option value="agendado">Agendado</option>
            <option value="em_andamento">Em Andamento</option>
            <option value="concluido">Concluído</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
        <div class="input-group">
          <label for="observacoes" class="input-label">Observações</label>
          <textarea
            id="observacoes"
            v-model="form.observacoes"
            class="textarea"
            rows="3"
          ></textarea>
        </div>
      </form>
      <template #footer>
        <button type="button" class="btn btn-outline" @click="closeModal">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="saveCronograma">Salvar</button>
      </template>
    </Offcanvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useToast } from 'vue-toastification';
import { cronogramaService } from '../services/cronogramaService.js';
import { equipeService } from '../services/equipeService.js';
import { materialService } from '../services/materialService.js';
import { carroService } from '../services/carroService.js';
import ChecklistMaterial from '../components/instalacao/ChecklistMaterial.vue';
import Offcanvas from '../components/common/Offcanvas.vue';
import Button from '../components/common/Button.vue';
import Input from '../components/common/Input.vue';
import Loading from '../components/common/Loading.vue';

const toast = useToast();

const cronogramas = ref([]);
const orcamentos = ref([]);
const equipes = ref([]);
const materiais = ref([]);
const carros = ref([]);
const loading = ref(true);
const showModal = ref(false);
const editingCronograma = ref(null);
const selectedMateriais = ref([]);
const materialQuantidades = ref({});
const form = ref({
  orcamento_id: null,
  data_instalacao: '',
  hora_inicio: '',
  hora_fim: '',
  endereco: '',
  observacoes: '',
  status: 'agendado',
  equipes: [],
  carros: []
});
const errors = ref({});

// Limpar estado quando o modal fechar
watch(showModal, (newValue) => {
  if (!newValue) {
    editingCronograma.value = null;
    form.value = {
      orcamento_id: null,
      data_instalacao: '',
      hora_inicio: '',
      hora_fim: '',
      endereco: '',
      observacoes: '',
      status: 'agendado',
      equipes: [],
      carros: []
    };
    selectedMateriais.value = [];
    materialQuantidades.value = {};
    errors.value = {};
  }
});

onMounted(() => {
  loadData();
});

const loadData = async () => {
  try {
    loading.value = true;
    const [cronogramasData, orcamentosData, equipesData, materiaisData, carrosData] = await Promise.all([
      cronogramaService.getAll(),
      cronogramaService.getOrcamentos(),
      equipeService.getAll(),
      materialService.getAll(),
      carroService.getAll()
    ]);
    cronogramas.value = cronogramasData;
    orcamentos.value = orcamentosData;
    equipes.value = equipesData;
    materiais.value = materiaisData;
    carros.value = carrosData;
  } catch (error) {
    toast.error('Erro ao carregar dados');
  } finally {
    loading.value = false;
  }
};

const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR');
};

const getStatusLabel = (status) => {
  const labels = {
    agendado: 'Agendado',
    em_andamento: 'Em Andamento',
    concluido: 'Concluído',
    cancelado: 'Cancelado'
  };
  return labels[status] || status;
};

const getStatusClass = (status) => {
  const classes = {
    agendado: 'status-scheduled',
    em_andamento: 'status-in-progress',
    concluido: 'status-completed',
    cancelado: 'status-cancelled'
  };
  return classes[status] || '';
};

const openModal = (cronograma = null) => {
  // Limpar estado anterior
  editingCronograma.value = null;
  form.value = {
    orcamento_id: null,
    data_instalacao: '',
    hora_inicio: '',
    hora_fim: '',
    endereco: '',
    observacoes: '',
    status: 'agendado',
    equipes: [],
    carros: []
  };
  selectedMateriais.value = [];
  materialQuantidades.value = {};
  errors.value = {};
  
  // Se for edição, preencher os dados
  if (cronograma && cronograma.id) {
    editingCronograma.value = cronograma;
    form.value = {
      orcamento_id: cronograma.orcamento_id,
      data_instalacao: cronograma.data_instalacao,
      hora_inicio: cronograma.hora_inicio || '',
      hora_fim: cronograma.hora_fim || '',
      endereco: cronograma.endereco,
      observacoes: cronograma.observacoes || '',
      status: cronograma.status,
      equipes: cronograma.equipes?.map(e => e.id) || [],
      carros: cronograma.carros?.map(c => c.id) || []
    };
    selectedMateriais.value = cronograma.materiais?.map(m => m.id) || [];
    cronograma.materiais?.forEach(m => {
      materialQuantidades.value[m.id] = m.quantidade_necessaria;
    });
  }
  
  showModal.value = true;
};

const closeModal = () => {
  showModal.value = false;
  editingCronograma.value = null;
  form.value = {
    orcamento_id: null,
    data_instalacao: '',
    hora_inicio: '',
    hora_fim: '',
    endereco: '',
    observacoes: '',
    status: 'agendado',
    equipes: [],
    carros: []
  };
  selectedMateriais.value = [];
  materialQuantidades.value = {};
  errors.value = {};
};

const saveCronograma = async () => {
  if (!form.value.data_instalacao) {
    errors.value.data_instalacao = 'Data é obrigatória';
    return;
  }
  if (!form.value.endereco.trim()) {
    errors.value.endereco = 'Endereço é obrigatório';
    return;
  }

  try {
    const materiaisData = selectedMateriais.value.map(id => ({
      material_id: id,
      quantidade_necessaria: materialQuantidades.value[id] || 1
    }));

    const cronogramaData = {
      ...form.value,
      materiais: materiaisData
    };

    // Verificar se é edição (deve ter id válido)
    if (editingCronograma.value && editingCronograma.value.id) {
      await cronogramaService.update(editingCronograma.value.id, cronogramaData);
      toast.success('Cronograma atualizado com sucesso!');
    } else {
      await cronogramaService.create(cronogramaData);
      toast.success('Cronograma criado com sucesso!');
    }
    closeModal();
    loadData();
  } catch (error) {
    toast.error(error.response?.data?.error || 'Erro ao salvar cronograma');
    console.error('Erro ao salvar cronograma:', error);
  }
};

const editCronograma = (cronograma) => {
  openModal(cronograma);
};

const deleteCronograma = async (id) => {
  if (!confirm('Tem certeza que deseja excluir este cronograma?')) {
    return;
  }

  try {
    await cronogramaService.delete(id);
    toast.success('Cronograma excluído com sucesso!');
    loadData();
  } catch (error) {
    toast.error('Erro ao excluir cronograma');
  }
};
</script>

<style scoped>
.cronograma-page {
  max-width: 1200px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.cronogramas-list {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.cronograma-card {
  background-color: var(--card-bg);
  border-radius: 0.5rem;
  box-shadow: var(--shadow);
  padding: 1.5rem;
}

.cronograma-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
  gap: 1rem;
}

.cronograma-header h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin: 0 0 0.5rem 0;
}

.cronograma-cliente {
  color: var(--text-light);
  font-size: 0.875rem;
  margin: 0 0 0.5rem 0;
}

.cronograma-data {
  font-size: 0.875rem;
  color: var(--text-color);
  margin: 0;
}

.cronograma-actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

.status-badge {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 500;
}

.status-scheduled {
  background-color: #dbeafe;
  color: #1e40af;
}

.status-in-progress {
  background-color: #fef3c7;
  color: #92400e;
}

.status-completed {
  background-color: #d1fae5;
  color: #065f46;
}

.status-cancelled {
  background-color: #fee2e2;
  color: #991b1b;
}

.cronograma-info {
  padding-top: 1rem;
  border-top: 1px solid var(--border-color);
}

.cronograma-section {
  margin-top: 1rem;
}

.tags-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-top: 0.5rem;
}

.tag {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  background-color: var(--bg-color);
  border-radius: 9999px;
  font-size: 0.875rem;
}

.materiais-checklist {
  margin-top: 0.5rem;
}

.material-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  font-size: 0.875rem;
}

.cronograma-observacoes {
  margin-top: 1rem;
  font-size: 0.875rem;
  color: var(--text-light);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.form-row-small {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
}

.materiais-select {
  max-height: 200px;
  overflow-y: auto;
  border: 1px solid var(--border-color);
  border-radius: 0.375rem;
  padding: 0.5rem;
}

.material-select-item {
  display: flex;
  align-items: center;
  padding: 0.5rem;
  gap: 0.5rem;
}

.empty-state {
  text-align: center;
  padding: 3rem;
  color: var(--text-light);
}

@media (max-width: 768px) {
  .cronograma-header {
    flex-direction: column;
  }

  .form-row,
  .form-row-small {
    grid-template-columns: 1fr;
  }

  .page-header {
    flex-direction: column;
    align-items: stretch;
    gap: 1rem;
  }
}
</style>
