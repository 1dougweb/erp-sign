import pool from '../config/database.js';

export const getCronogramas = async (req, res) => {
  try {
    const [cronogramas] = await pool.execute(
      `SELECT c.*, o.numero as orcamento_numero, o.cliente_nome 
       FROM cronograma_instalacao c 
       LEFT JOIN orcamentos o ON c.orcamento_id = o.id 
       ORDER BY c.data_instalacao DESC, c.hora_inicio ASC`
    );

    // Buscar equipes, materiais e carros de cada cronograma
    for (const cronograma of cronogramas) {
      // Equipes
      const [equipes] = await pool.execute(
        `SELECT e.* FROM equipes e 
         INNER JOIN cronograma_equipe ce ON e.id = ce.equipe_id 
         WHERE ce.cronograma_id = ?`,
        [cronograma.id]
      );
      cronograma.equipes = equipes;

      // Materiais
      const [materiais] = await pool.execute(
        `SELECT m.*, cm.quantidade_necessaria, cm.quantidade_confirmada 
         FROM materiais m 
         INNER JOIN cronograma_material cm ON m.id = cm.material_id 
         WHERE cm.cronograma_id = ?`,
        [cronograma.id]
      );
      cronograma.materiais = materiais;

      // Carros
      const [carros] = await pool.execute(
        `SELECT c.* FROM carros c 
         INNER JOIN cronograma_carro cc ON c.id = cc.carro_id 
         WHERE cc.cronograma_id = ?`,
        [cronograma.id]
      );
      cronograma.carros = carros;
    }

    res.json(cronogramas);
  } catch (error) {
    console.error('Erro ao buscar cronogramas:', error);
    res.status(500).json({ error: 'Erro ao buscar cronogramas' });
  }
};

export const createCronograma = async (req, res) => {
  try {
    const { orcamento_id, data_instalacao, hora_inicio, hora_fim, endereco, observacoes, equipes, materiais, carros } = req.body;

    if (!data_instalacao || !endereco) {
      return res.status(400).json({ error: 'Data de instalação e endereço são obrigatórios' });
    }

    const [result] = await pool.execute(
      'INSERT INTO cronograma_instalacao (orcamento_id, data_instalacao, hora_inicio, hora_fim, endereco, observacoes) VALUES (?, ?, ?, ?, ?, ?)',
      [orcamento_id || null, data_instalacao, hora_inicio || null, hora_fim || null, endereco, observacoes || null]
    );

    const cronogramaId = result.insertId;

    // Adicionar equipes
    if (Array.isArray(equipes) && equipes.length > 0) {
      for (const equipeId of equipes) {
        await pool.execute(
          'INSERT INTO cronograma_equipe (cronograma_id, equipe_id) VALUES (?, ?)',
          [cronogramaId, equipeId]
        );
      }
    }

    // Adicionar materiais
    if (Array.isArray(materiais) && materiais.length > 0) {
      for (const material of materiais) {
        await pool.execute(
          'INSERT INTO cronograma_material (cronograma_id, material_id, quantidade_necessaria) VALUES (?, ?, ?)',
          [cronogramaId, material.material_id, material.quantidade_necessaria || 1]
        );
      }
    }

    // Adicionar carros
    if (Array.isArray(carros) && carros.length > 0) {
      for (const carroId of carros) {
        await pool.execute(
          'INSERT INTO cronograma_carro (cronograma_id, carro_id) VALUES (?, ?)',
          [cronogramaId, carroId]
        );
      }
    }

    const [cronograma] = await pool.execute(
      `SELECT c.*, o.numero as orcamento_numero, o.cliente_nome 
       FROM cronograma_instalacao c 
       LEFT JOIN orcamentos o ON c.orcamento_id = o.id 
       WHERE c.id = ?`,
      [cronogramaId]
    );

    // Buscar relacionamentos
    const [equipesList] = await pool.execute(
      `SELECT e.* FROM equipes e 
       INNER JOIN cronograma_equipe ce ON e.id = ce.equipe_id 
       WHERE ce.cronograma_id = ?`,
      [cronogramaId]
    );

    const [materiaisList] = await pool.execute(
      `SELECT m.*, cm.quantidade_necessaria, cm.quantidade_confirmada 
       FROM materiais m 
       INNER JOIN cronograma_material cm ON m.id = cm.material_id 
       WHERE cm.cronograma_id = ?`,
      [cronogramaId]
    );

    const [carrosList] = await pool.execute(
      `SELECT c.* FROM carros c 
       INNER JOIN cronograma_carro cc ON c.id = cc.carro_id 
       WHERE cc.cronograma_id = ?`,
      [cronogramaId]
    );

    cronograma[0].equipes = equipesList;
    cronograma[0].materiais = materiaisList;
    cronograma[0].carros = carrosList;

    res.status(201).json(cronograma[0]);
  } catch (error) {
    console.error('Erro ao criar cronograma:', error);
    res.status(500).json({ error: 'Erro ao criar cronograma' });
  }
};

export const updateCronograma = async (req, res) => {
  try {
    const { id } = req.params;
    const { orcamento_id, data_instalacao, hora_inicio, hora_fim, endereco, observacoes, status, equipes, materiais, carros } = req.body;

    const [cronogramas] = await pool.execute(
      'SELECT * FROM cronograma_instalacao WHERE id = ?',
      [id]
    );

    if (cronogramas.length === 0) {
      return res.status(404).json({ error: 'Cronograma não encontrado' });
    }

    await pool.execute(
      'UPDATE cronograma_instalacao SET orcamento_id = ?, data_instalacao = ?, hora_inicio = ?, hora_fim = ?, endereco = ?, observacoes = ?, status = ? WHERE id = ?',
      [orcamento_id || null, data_instalacao, hora_inicio || null, hora_fim || null, endereco, observacoes || null, status || cronogramas[0].status, id]
    );

    // Atualizar equipes
    if (Array.isArray(equipes)) {
      await pool.execute('DELETE FROM cronograma_equipe WHERE cronograma_id = ?', [id]);
      for (const equipeId of equipes) {
        await pool.execute(
          'INSERT INTO cronograma_equipe (cronograma_id, equipe_id) VALUES (?, ?)',
          [id, equipeId]
        );
      }
    }

    // Atualizar materiais
    if (Array.isArray(materiais)) {
      await pool.execute('DELETE FROM cronograma_material WHERE cronograma_id = ?', [id]);
      for (const material of materiais) {
        await pool.execute(
          'INSERT INTO cronograma_material (cronograma_id, material_id, quantidade_necessaria, quantidade_confirmada) VALUES (?, ?, ?, ?)',
          [id, material.material_id, material.quantidade_necessaria || 1, material.quantidade_confirmada || 0]
        );
      }
    }

    // Atualizar carros
    if (Array.isArray(carros)) {
      await pool.execute('DELETE FROM cronograma_carro WHERE cronograma_id = ?', [id]);
      for (const carroId of carros) {
        await pool.execute(
          'INSERT INTO cronograma_carro (cronograma_id, carro_id) VALUES (?, ?)',
          [id, carroId]
        );
      }
    }

    const [updated] = await pool.execute(
      `SELECT c.*, o.numero as orcamento_numero, o.cliente_nome 
       FROM cronograma_instalacao c 
       LEFT JOIN orcamentos o ON c.orcamento_id = o.id 
       WHERE c.id = ?`,
      [id]
    );

    res.json(updated[0]);
  } catch (error) {
    console.error('Erro ao atualizar cronograma:', error);
    res.status(500).json({ error: 'Erro ao atualizar cronograma' });
  }
};

export const updateMaterialQuantidade = async (req, res) => {
  try {
    const { cronogramaId, materialId } = req.params;
    const { quantidade_confirmada } = req.body;

    const [existing] = await pool.execute(
      'SELECT * FROM cronograma_material WHERE cronograma_id = ? AND material_id = ?',
      [cronogramaId, materialId]
    );

    if (existing.length === 0) {
      return res.status(404).json({ error: 'Material não encontrado no cronograma' });
    }

    await pool.execute(
      'UPDATE cronograma_material SET quantidade_confirmada = ? WHERE cronograma_id = ? AND material_id = ?',
      [quantidade_confirmada || 0, cronogramaId, materialId]
    );

    const [updated] = await pool.execute(
      `SELECT m.*, cm.quantidade_necessaria, cm.quantidade_confirmada 
       FROM materiais m 
       INNER JOIN cronograma_material cm ON m.id = cm.material_id 
       WHERE cm.cronograma_id = ? AND cm.material_id = ?`,
      [cronogramaId, materialId]
    );

    res.json(updated[0]);
  } catch (error) {
    console.error('Erro ao atualizar quantidade do material:', error);
    res.status(500).json({ error: 'Erro ao atualizar quantidade do material' });
  }
};

export const deleteCronograma = async (req, res) => {
  try {
    const { id } = req.params;

    const [cronogramas] = await pool.execute(
      'SELECT * FROM cronograma_instalacao WHERE id = ?',
      [id]
    );

    if (cronogramas.length === 0) {
      return res.status(404).json({ error: 'Cronograma não encontrado' });
    }

    await pool.execute('DELETE FROM cronograma_instalacao WHERE id = ?', [id]);

    res.json({ message: 'Cronograma excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir cronograma:', error);
    res.status(500).json({ error: 'Erro ao excluir cronograma' });
  }
};

export const getOrcamentos = async (req, res) => {
  try {
    const [orcamentos] = await pool.execute(
      'SELECT * FROM orcamentos WHERE status IN ("aprovado", "em_andamento") ORDER BY created_at DESC'
    );
    res.json(orcamentos);
  } catch (error) {
    console.error('Erro ao buscar orçamentos:', error);
    res.status(500).json({ error: 'Erro ao buscar orçamentos' });
  }
};

export const getTiposInstalacao = async (req, res) => {
  try {
    const [tipos] = await pool.execute(
      'SELECT * FROM tipos_instalacao ORDER BY nome ASC'
    );
    res.json(tipos);
  } catch (error) {
    console.error('Erro ao buscar tipos de instalação:', error);
    res.status(500).json({ error: 'Erro ao buscar tipos de instalação' });
  }
};
