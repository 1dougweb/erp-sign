<template>
  <div class="carros-page">
    <div class="page-header">
      <h1 class="page-title">Carros</h1>
      <Button @click="openModal">+ Novo Carro</Button>
    </div>

    <Loading v-if="loading" />
    <div v-else-if="carros.length === 0" class="empty-state">
      <p>Nenhum carro cadastrado. Cadastre o primeiro!</p>
    </div>
    <div v-else class="carros-list">
      <div v-for="carro in carros" :key="carro.id" class="carro-card">
        <div class="carro-header">
          <div>
            <h3>{{ carro.modelo }}</h3>
            <p class="carro-info">
              <span v-if="carro.marca">{{ carro.marca }} - </span>
              <span v-if="carro.ano">{{ carro.ano }}</span>
            </p>
            <p class="carro-placa">Placa: {{ carro.placa }}</p>
          </div>
          <div class="carro-actions">
            <button class="btn btn-outline" @click="editCarro(carro)">Editar</button>
            <button class="btn btn-danger" @click="deleteCarro(carro.id)">Excluir</button>
          </div>
        </div>
        <span :class="['status-badge', carro.disponivel ? 'status-available' : 'status-unavailable']">
          {{ carro.disponivel ? 'Disponível' : 'Indisponível' }}
        </span>
      </div>
    </div>

    <Offcanvas
      v-model:show="showModal"
      :title="editingCarro && editingCarro.id ? 'Editar Carro' : 'Novo Carro'"
      position="right"
      @confirm="saveCarro"
      @close="closeModal"
    >
      <form @submit.prevent="saveCarro" class="form">
        <Input
          id="placa"
          v-model="form.placa"
          label="Placa *"
          placeholder="ABC-1234"
          :error="errors.placa"
          required
        />
        <Input
          id="modelo"
          v-model="form.modelo"
          label="Modelo *"
          placeholder="Ex: Fiesta, Gol"
          :error="errors.modelo"
          required
        />
        <div class="form-row">
          <Input
            id="marca"
            v-model="form.marca"
            label="Marca"
            placeholder="Ex: Ford, Volkswagen"
          />
          <Input
            id="ano"
            v-model.number="form.ano"
            label="Ano"
            type="number"
            placeholder="2020"
          />
        </div>
        <div class="input-group">
          <label class="checkbox-label">
            <input type="checkbox" v-model="form.disponivel" />
            Disponível
          </label>
        </div>
      </form>
      <template #footer>
        <button type="button" class="btn btn-outline" @click="closeModal">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="saveCarro">Salvar</button>
      </template>
    </Offcanvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useToast } from 'vue-toastification';
import { carroService } from '../services/carroService.js';
import Offcanvas from '../components/common/Offcanvas.vue';
import Button from '../components/common/Button.vue';
import Input from '../components/common/Input.vue';
import Loading from '../components/common/Loading.vue';

const toast = useToast();

const carros = ref([]);
const loading = ref(true);
const showModal = ref(false);
const editingCarro = ref(null);
const form = ref({
  placa: '',
  modelo: '',
  marca: '',
  ano: null,
  disponivel: true
});
const errors = ref({});

// Limpar estado quando o modal fechar
watch(showModal, (newValue) => {
  if (!newValue) {
    editingCarro.value = null;
    form.value = { placa: '', modelo: '', marca: '', ano: null, disponivel: true };
    errors.value = {};
  }
});

onMounted(() => {
  loadCarros();
});

const loadCarros = async () => {
  try {
    loading.value = true;
    carros.value = await carroService.getAll();
  } catch (error) {
    toast.error('Erro ao carregar carros');
  } finally {
    loading.value = false;
  }
};

const openModal = (carro = null) => {
  // Limpar estado anterior
  editingCarro.value = null;
  form.value = { placa: '', modelo: '', marca: '', ano: null, disponivel: true };
  errors.value = {};
  
  // Se for edição, preencher os dados
  if (carro && carro.id) {
    editingCarro.value = carro;
    form.value = { ...carro };
  }
  
  showModal.value = true;
};

const closeModal = () => {
  showModal.value = false;
  editingCarro.value = null;
  form.value = { placa: '', modelo: '', marca: '', ano: null, disponivel: true };
  errors.value = {};
};

const saveCarro = async () => {
  if (!form.value.placa.trim()) {
    errors.value.placa = 'Placa é obrigatória';
    return;
  }
  if (!form.value.modelo.trim()) {
    errors.value.modelo = 'Modelo é obrigatório';
    return;
  }

  try {
    // Verificar se é edição (deve ter id válido)
    if (editingCarro.value && editingCarro.value.id) {
      await carroService.update(editingCarro.value.id, form.value);
      toast.success('Carro atualizado com sucesso!');
    } else {
      await carroService.create(form.value);
      toast.success('Carro criado com sucesso!');
    }
    closeModal();
    loadCarros();
  } catch (error) {
    toast.error(error.response?.data?.error || 'Erro ao salvar carro');
    console.error('Erro ao salvar carro:', error);
  }
};

const editCarro = (carro) => {
  openModal(carro);
};

const deleteCarro = async (id) => {
  if (!confirm('Tem certeza que deseja excluir este carro?')) {
    return;
  }

  try {
    await carroService.delete(id);
    toast.success('Carro excluído com sucesso!');
    loadCarros();
  } catch (error) {
    toast.error('Erro ao excluir carro');
  }
};
</script>

<style scoped>
.carros-page {
  max-width: 1200px;
}


.carros-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
}

.carro-card {
  background-color: var(--card-bg);
  border-radius: 0.5rem;
  box-shadow: var(--shadow);
  padding: 1.5rem;
}

.carro-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
  gap: 1rem;
}

.carro-header h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin: 0 0 0.5rem 0;
}

.carro-info {
  color: var(--text-light);
  font-size: 0.875rem;
  margin: 0 0 0.5rem 0;
}

.carro-placa {
  font-size: 1rem;
  font-weight: 600;
  color: var(--primary-color);
  margin: 0;
}

.carro-actions {
  display: flex;
  gap: 0.5rem;
  flex-shrink: 0;
}

.status-badge {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 500;
}

.status-available {
  background-color: #d1fae5;
  color: #065f46;
}

.status-unavailable {
  background-color: #fee2e2;
  color: #991b1b;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.empty-state {
  text-align: center;
  padding: 3rem;
  color: var(--text-light);
}

@media (max-width: 768px) {
  .carros-list {
    grid-template-columns: 1fr;
  }

  .form-row {
    grid-template-columns: 1fr;
  }

}
</style>
