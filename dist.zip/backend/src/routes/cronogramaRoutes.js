import express from 'express';
import { getCronogramas, createCronograma, updateCronograma, deleteCronograma, getOrcamentos, getTiposInstalacao, updateMaterialQuantidade } from '../controllers/cronogramaController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

router.use(authenticateToken);

router.get('/', getCronogramas);
router.post('/', createCronograma);
router.put('/:id', updateCronograma);
router.delete('/:id', deleteCronograma);
router.put('/:cronogramaId/materiais/:materialId/quantidade', updateMaterialQuantidade);
router.get('/orcamentos', getOrcamentos);
router.get('/tipos-instalacao', getTiposInstalacao);

export default router;
